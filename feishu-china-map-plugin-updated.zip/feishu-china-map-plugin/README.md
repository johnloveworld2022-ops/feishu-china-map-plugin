# 飞书仪表盘中国地图插件

一个用于飞书仪表盘的中国地图可视化插件，可以根据地区负责人开发的机构数量进行颜色标记。

## 功能特性

- 🗺️ 交互式中国地图展示
- 🎨 基于机构数量的颜色深浅标记
- 👥 地区负责人信息管理
- 📊 机构数据可视化
- 🔐 飞书平台集成和权限控制
- 📱 响应式设计，支持多设备

## 技术栈

- **前端框架**: React 18 + TypeScript
- **构建工具**: Vite
- **样式方案**: Tailwind CSS
- **地图可视化**: ECharts
- **状态管理**: Zustand
- **代码规范**: ESLint + Prettier

## 快速开始

### 安装依赖

\`\`\`bash
npm install
\`\`\`

### 开发模式

\`\`\`bash
npm run dev
\`\`\`

### 构建生产版本

\`\`\`bash
npm run build
\`\`\`

### 代码检查和格式化

\`\`\`bash
# 代码检查
npm run lint

# 自动修复
npm run lint:fix

# 代码格式化
npm run format
\`\`\`

## 项目结构

\`\`\`
feishu-china-map-dashboard/
├── src/
│   ├── components/          # React 组件
│   ├── stores/             # Zustand 状态管理
│   ├── services/           # API 服务
│   ├── types/              # TypeScript 类型定义
│   ├── utils/              # 工具函数
│   ├── assets/             # 静态资源
│   └── styles/             # 样式文件
├── public/                 # 公共资源
├── feishu-plugin.json      # 飞书插件配置
└── package.json
\`\`\`

## 开发指南

### 地区颜色方案

- **华东地区**: 蓝色系 (#3b82f6)
- **华南地区**: 红色系 (#ef4444)
- **华西地区**: 绿色系 (#22c55e)
- **华北地区**: 黄色系 (#eab308)

### 数据结构

\`\`\`typescript
interface RegionData {
  id: string;
  name: string;           // 省份名称
  regionType: string;     // 管理区域
  manager: {
    id: string;
    name: string;
    contact: string;
  };
  institutions: Institution[];
}
\`\`\`

## 部署

1. 构建项目: \`npm run build\`
2. 将 \`dist\` 目录内容上传到飞书开发者平台
3. 配置插件权限和作用域
4. 提交审核

## 贡献指南

1. Fork 项目
2. 创建功能分支: \`git checkout -b feature/new-feature\`
3. 提交更改: \`git commit -am 'Add new feature'\`
4. 推送分支: \`git push origin feature/new-feature\`
5. 提交 Pull Request

## 许可证

MIT License

## 联系方式

- 邮箱: 1281991939@qq.com
- GitHub: [项目地址](https://github.com/developer/feishu-china-map-dashboard)